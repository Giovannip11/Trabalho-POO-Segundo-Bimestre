
import greenfoot.*;  

public class MyWorld extends World {
    private boolean gameStarted = false;
    

    public MyWorld() {    
        super(800, 800, 1); 
        prepare();
    }
    
    
    private void prepare() {
         
        
    }

    public void act() {
        if (!gameStarted) {
            gameStarted = true;
            return;
        }
        checkGameOver();
    }

    private void checkGameOver() {
        if (getObjects(Foguete.class).isEmpty()) {
            showText("Você Perdeu!", getWidth() / 2, getHeight() / 2);
            Greenfoot.stop();
        } else if (getObjects(abelha.class).isEmpty()) {
            showText("Você Venceu!", getWidth() / 2, getHeight() / 2);
            Greenfoot.stop();
        }
    }
}





