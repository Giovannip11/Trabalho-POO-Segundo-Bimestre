import greenfoot.*;  

public class MenuScreen extends MyWorld
{
    public MenuScreen()
    {    

        showText("Pressione ESPAÇO para começar o jogo", getWidth() / 2, getHeight() / 2);
        showText("Use as setas para mover o foguete e 'F' para atirar", getWidth() / 2, getHeight() / 2 + 20);
        prepare();
    }

    public void act() {
        if (Greenfoot.isKeyDown("space")) {
            Greenfoot.setWorld(new Espaco());
        }
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
