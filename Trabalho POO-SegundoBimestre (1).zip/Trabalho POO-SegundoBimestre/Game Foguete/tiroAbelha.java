import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class tiroAbelha extends Actor
{
    private int speed = 2; 
    private abelha owner;
    
    public tiroAbelha(abelha owner) {
        this.owner = owner;
        getImage().scale(12, 8);  
    }
   
    
    public void act() {
        moveAbelha();
        removeIfOutofBounds();
    }
    
    public void moveAbelha() {
        setLocation(getX() + speed, getY());
    }
    
    public void removeIfOutofBounds(){
        if( getX()<=0 || getX() >= getWorld().getWidth()){
            getWorld().removeObject(this);
            
        }
    }
    public void checkActive(){
         if(owner != null && !owner.isActive()){
            getWorld().removeObject(this);
        }
        
    }
    }


