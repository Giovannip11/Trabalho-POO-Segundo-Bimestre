
# Trabalho-Segundo-Bimestre-POO

Trabalho de POO feito por Giovanni Milan Câmara Pinto.

links:https://www.greenfoot.org/scenarios/25287

Utilizando as IDEs greenfoot e NetBeans, foi possível fazer as atividades 1 e 2, o video tem mais detalhes sobre o projeto e como ele funciona e a lógica que foi desenvolvida

