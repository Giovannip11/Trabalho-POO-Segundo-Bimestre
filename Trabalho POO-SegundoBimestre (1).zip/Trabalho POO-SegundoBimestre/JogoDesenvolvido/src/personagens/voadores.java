
package personagens;




public abstract class voadores extends personagem{
    
    
    
    public void voar(){
        
    }
    public void som(){
        
    }
    

     
}
