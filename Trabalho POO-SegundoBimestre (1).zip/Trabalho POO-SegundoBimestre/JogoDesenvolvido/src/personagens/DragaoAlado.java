
package personagens;

import armas.bolaDeFogo;


public class DragaoAlado extends voadores{
    public DragaoAlado(){
        arma = new bolaDeFogo();
    }
}
