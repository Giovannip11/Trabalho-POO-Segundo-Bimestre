
package personagens;

public class Mago extends personagem{
    
    @Override
    public void desenhar(){
        super.desenhar();
}
}
