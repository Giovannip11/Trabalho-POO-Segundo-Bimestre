
package personagens;


public class LutSUMO extends personagem {
    
    
    @Override
        public void desenhar(){
        super.desenhar();
    }
}
