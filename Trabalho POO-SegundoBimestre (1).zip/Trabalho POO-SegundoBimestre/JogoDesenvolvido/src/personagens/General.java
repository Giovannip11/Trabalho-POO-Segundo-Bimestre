
package personagens;


public class General extends personagem {
    
        @Override
        public void desenhar(){
        super.desenhar();
    }
}
