
package personagens;


public class Soldado extends personagem {
    
    @Override
    public void desenhar(){
        super.desenhar();
    }
    @Override
    public void arma(){
        
       
    }
}
