
package armas;


public interface  Arma_IF {
  public void usarArma();
}
